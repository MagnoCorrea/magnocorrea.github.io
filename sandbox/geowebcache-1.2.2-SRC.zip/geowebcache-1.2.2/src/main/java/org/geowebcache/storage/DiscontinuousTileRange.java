/**
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Arne Kepp, OpenGeo, Copyright 2010
 *  
 */
package org.geowebcache.storage;

import org.geowebcache.mime.MimeType;
import org.geowebcache.rest.seed.RasterMask;

/**
 * This class is a TileRange object with an additional filter
 */
public class DiscontinuousTileRange extends TileRange {

    final private RasterMask rasterMask;
    
    public DiscontinuousTileRange(
            String layerName, String gridSetId, 
            int zoomStart, int zoomStop, 
            RasterMask rasterMask,
            MimeType mimeType, String parameters) {
        
        super(layerName, gridSetId, 
                zoomStart, zoomStop, 
                rasterMask.getGridCoverages(), 
                mimeType, parameters);
        
        this.rasterMask = rasterMask;
    }
    
    public boolean contains(long[] idx) {
        if(super.contains(idx)) {
            return rasterMask.lookup(idx);
        }
        
        return false;
    }
}
